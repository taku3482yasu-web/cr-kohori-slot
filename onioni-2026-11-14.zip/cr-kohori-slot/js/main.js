// =====================================================================
// 起動と1ゲームの流れ
//   レバーON → コイン投入 → 抽選 → リール回転・停止 → 払い出し → 状態更新 → 演出
// =====================================================================

(() => {
    const config = window.GAME_CONFIG;
    const savedState = SaveData.load(config);
    const state = savedState || createInitialState(config);

    const spinButton = document.getElementById('spin-button');
    const buyCoinsButton = document.getElementById('buy-coins-button');
    const fsBuyButton = document.getElementById('fs-buy-button');
    const stopButtons = [1, 2, 3].map(n => document.getElementById(`stop-button-${n}`));
    const reelElements = [1, 2, 3].map(n => document.getElementById(`reel${n}`));
    // 筐体 (css/cabinet.css): 払い出しの 7 セグと、当たった ラインの 番号ランプ
    const payoutDisplay = document.getElementById('cab-payout');
    const lineLamps = [...document.querySelectorAll('.cab-line')];
    const setPayout = n => { if (payoutDisplay) payoutDisplay.textContent = n; };
    const lightLine = line => lineLamps.forEach(el => el.classList.toggle('on', line !== null && Number(el.dataset.line) === line));
    let debugNextRole = null;   // デバッグ: 次のゲームの役を指定
    let debugNotice = null;     // デバッグ: 次のゲームの予告の種類を指定 ('stepUp' | 'gun')
    let debugEndCard = -1;      // デバッグ: 最後に見た RASH 終了画面の絵の番号

    // bgm: false なら 曲は 切り替えない (結果の 演出の 前。次の 場面の 曲が 先に 流れて しまうため。2026-11-10)
    function refresh(bgm = true) {
        UI.update(state);
        if (bgm) {
            const track = bgmTrack(state);
            Bgm.play(track, bgmFallback(state, track));
        }
    }

    // ロングフリーズ: STOP を押せなくし、BGM を止めて液晶の演出を流す
    async function playLongFreeze(stopSpinSound) {
        stopSpinSound();
        Reels.lockStops(true);
        Bgm.setPaused(true);
        await Lcd.longFreeze();
        Bgm.setPaused(false);
        Reels.lockStops(false);
    }

    // 場面ごとの BGM
    // おにおにRASH の 曲 (2026-11-13 ユーザー指定: 曲を 増やす)。RASH に 入る たびに、sound/ に 置いて ある 曲から ランダムで 1 曲。
    //   置いて いない 曲は 選ばない。1 曲も ない ときは battle (チップチューン)。RASH の あいだ (特化ゾーン・復活を はさんでも) は 同じ 曲
    const RASH_SONGS = ['battle', 'battle2', 'rash2', 'rash3', 'rash4'];
    let rashSong = null;
    // SUPERおにおにRASH の 曲 (2026-11-14): 歌なし (super) と 歌あり (super2) から、SUPER に 入る たびに ランダム
    const SUPER_SONGS = ['super', 'super2'];
    let superSong = null;
    // 通常時の ステージ別の 曲 (config.map.loop の マップ。曲の 名前 = マップの id。js/bgm.js の BGM_FILES)
    const STAGE_SONGS = ['tsugakuro', 'ongagawa', 'ebisucho'];
    // ない と わかった 曲は 選ばない (スマホでは 読み込みが 遅く まだ わからない ことが あるので、わからない 曲は 選んで よい。
    //   選んだ 曲が 読めなかった ときは チップチューンの 曲に なる)
    function pickSong(names) {
        const ok = names.filter(name => Bgm.fileState(name) !== false);
        return ok.length ? ok[Math.floor(Math.random() * ok.length)] : names[0];
    }
    const pickRashSong = () => pickSong(RASH_SONGS);

    // 上乗せ特化ゾーンの 見せ方 → 曲 (ファイルが ない ときは bgmFallback の 曲。js/bgm.js の BGM_FILES)
    const TOKKA_TRACKS = { fire: 'tokkaFire', ikkeki: 'tokkaIkkeki', asahara: 'tokkaAsahara' };
    // 特化ゾーンの 曲の ファイルが ない ときに 流す チップチューン (今までと 同じく RASH / SUPER の 曲)。ほかの 曲は null (BGM_FILES の fallback)
    function bgmFallback(s, track) {
        if (!Object.values(TOKKA_TRACKS).includes(track)) return null;
        return s.mode === MODES.SUPER_RASH ? 'super' : 'battle';
    }
    function bgmTrack(s) {
        if (StateMachine.isRashMode(s) && s.rash.phase === RASH_PHASES.REVIVAL) return 'defeat';   // 復活待ちは負けたように見せる
        if (StateMachine.isRashMode(s) && s.rash.phase === RASH_PHASES.TOKKA) {
            // 上乗せ特化ゾーンは 見せ方ごとの 曲 (2026-11-13 ユーザー指定。Suno の 曲を 置く。sound/SUNO.md)
            const kind = s.rash.tokka.kind;
            if (kind === 'okaLamp') return 'okapipo';   // おかランプは ラップ入りの 曲 (ファイルが ない ときは ダンスの 曲)
            if (TOKKA_TRACKS[kind]) return TOKKA_TRACKS[kind];
        }
        if (s.mode === MODES.SUPER_RASH) {
            if (!superSong) superSong = pickSong(SUPER_SONGS);
            return superSong;
        }
        superSong = null;   // SUPER が 終わったら 次の SUPER で 選び直す
        if (s.mode === MODES.RASH) {
            if (!rashSong) rashSong = pickRashSong();
            return rashSong;
        }
        rashSong = null;   // RASH が 終わったら 次の RASH で 選び直す
        if (s.mode === MODES.CASTLE_CHALLENGE || s.normal.map === config.map.castle) return 'castle';
        if (s.normal.dance) return 'dance';
        // ステージ別の 曲 (2026-11-13 ユーザー指定)。その ステージの 曲が ない と わかって いれば field (field.mp3 か チップチューン)
        const stage = s.normal.map;
        if (STAGE_SONGS.includes(stage) && Bgm.fileState(stage) !== false) return stage;
        return 'field';
    }

    // 音は最初のユーザー操作のあとでないと鳴らせない
    function startAudio() {
        Sound.init();
        Bgm.init(Sound.context());
        Bgm.preload([...RASH_SONGS, ...SUPER_SONGS, ...STAGE_SONGS]);   // RASH・ステージの 曲が 置いて あるかを 先に 調べる
    }
    document.addEventListener('pointerdown', startAudio, { once: true });
    document.addEventListener('keydown', startAudio, { once: true });

    async function playGame() {
        startAudio();
        // レバーを叩け！ (2026-10-24): ゲームの 途中で レバーが 押せる のは この ときだけ
        if (PushButton.leverActive()) {
            PushButton.hitLever();
            return;
        }
        // 特化ゾーンの見せ方を選ぶ画面: レバーで決定
        if (Lcd.tokkaSelecting()) {
            Lcd.tokkaSelectInput('lever');
            return;
        }
        // オープニング中のレバーはスキップ
        if (Lcd.storyActive()) {
            Lcd.skipStory();
            return;
        }
        const cost = config.coins.spinCost;
        if (state.coins < cost) {
            Lcd.showMessage('NO COINS!', '#ff8080');
            buyCoinsButton.classList.add('attention');
            fsBuyButton.classList.add('attention');
            refresh();
            return;
        }

        spinButton.disabled = true;
        state.coins -= cost;
        setPayout(0);
        lightLine(null);
        Lcd.clearMessage();
        Lcd.hideTrophy();
        Lcd.hideFurukawa();
        // 復活待ちでレバー ON: 画面が暗転し、BGM も止まる (復活演出で鳴り直す)
        if (StateMachine.isRashMode(state) && state.rash.phase === RASH_PHASES.REVIVAL) {
            Lcd.revivalBlackout();
            Bgm.setPaused(true);
        }
        refresh();

        const outcome = debugNextRole ? Lottery.makeOutcome(debugNextRole, config) : Lottery.draw(state, config);
        debugNextRole = null;
        const effects = config.effects;
        Lcd.tokkaLever(outcome);   // 上乗せ特化ゾーン「おかランプ」: チャンス役でランプが点灯

        // 先読み予告 (レバーON で雪が降る)
        const previewRate = effects.preview[outcome.role] || 0;
        if (Math.random() < previewRate) {
            const gold = outcome.role !== 'miss' && Math.random() < effects.preview.goldRate;
            Lcd.startPreview(gold ? 2 : 1);
        }

        // ふるカワ: そのゲームの熱さに応じて出てきて、しゃべる
        const talk = Furukawa.talk(state, outcome, config);
        if (talk) Lcd.showFurukawa(talk);
        if (talk) Collection.hearFurukawa(state, talk.text, config);   // 図鑑のふるカワの説明・セリフ
        if (talk && talk.settingLine != null) SettingEstimate.countFurukawa(state, talk.settingLine);

        // 期待度の 演出 (2026-10-23 A3。js/hype.js): 熱さに 合わせて カットイン・先バレ音・確定音・金発光・フラッシュ・PUSH
        const heat = talk ? talk.heat : Furukawa.canAppear(state, config) ? Furukawa.heat(state, outcome, config) : 0;
        // 長押しの チャージは 先読みより 前に 決める (結果に かかわる ため)
        const chargeScene = GameFlow.drawCharge(state, outcome, config);
        // 結果の 先読み (2026-11-10 ユーザー指定): 金カットインは 当たり 確定・赤カットインは ガセなし。本番は 同じ 乱数で 打つ
        const verdict = GameFlow.predict(state, outcome, config);
        // 群予告 (2026-11-13 ユーザー指定): 当たりが 確定した ゲームだけ 出る 演出 (結果は 変えない)。デバッグの 指定は そのまま 出す
        outcome.gun = debugNotice === 'gun' ? Notice.allowed(state) : GameFlow.rollGun(state, outcome, verdict, config);
        const hype = Hype.fit(Hype.plan(heat, config), verdict, config);
        hype.push = LeverFx.tataki(state, hype.push, heat, config);   // レバーを叩け！ (2026-10-24)
        const leverFx = LeverFx.atLever(state, outcome, heat, config);   // レバブル・遅れ・逆回転 (2026-10-24)
        playHypeAtLever(hype);
        playLeverFx(leverFx);
        // 熱い ゲームは 液晶の 枠が 震える (2026-10-24 ユーザー指定)。熱さ 4 赤 / 5 金 / 6 虹
        const hf = config.hotFrame;
        Lcd.setHotFrame(heat >= hf.rainbow ? 3 : heat >= hf.gold ? 2 : heat >= hf.red ? 1 : 0);
        const inRash = StateMachine.isRashMode(state);   // 図鑑の「叩け」の 場面 (結果の あとでは 変わる ことが ある)
        ['buru', 'okure', 'reverse'].forEach(k => { if (leverFx[k]) Collection.seeLever(state, k); });
        // 通常時の予告 (ステップアップ予告・群予告。役で選ぶ)。期待度のカットインが出たゲームでは出さない
        // 群予告 (2026-11-13 ユーザー指定): 当たり 確定の ゲームだけ (GameFlow.rollGun)。出る ゲームは かならず 見せる
        if (!hype.cutin || debugNotice || outcome.gun) Lcd.playNotice(Notice.pick(state, outcome, config, Math.random, debugNotice));
        debugNotice = null;
        // 前兆と 違和感演出 (2026-10-23 A4。js/zencho.js)
        const zc = Zencho.beforeGame(state, config);
        if (!zc.zencho && state.mode === MODES.NORMAL && state.normal.zone) zc.zencho = 'zone';   // モードの ゾーン (A5)
        playZencho(zc);

        const stopOrder = [];
        let reach = null;
        let freezePlaying = null;
        let spinSound = null;
        const onStop = (i, count) => {
            Sound.stop(i);
            stopOrder.push(i);
            // ロングフリーズ: 左リール中段にチェリーが止まった瞬間に発生
            if (i === 0 && outcome.isFreeze) {
                freezePlaying = playLongFreeze(() => clearInterval(spinSound));
                return;
            }
            if (count === 2 && !outcome.isFreeze) {
                const remaining = [0, 1, 2].find(k => !stopOrder.includes(k));
                const reaches = Lottery.findReaches(outcome, stopOrder, config);
                reach = reaches.length ? reaches : null;
                if (reach) {
                    stopButtons[remaining].classList.add('reach');
                    Reels.setLamp(remaining, 'reach');
                    // 2 つ 以上は「どれが出るかな？」。7 の リーチの 赤カットインは 揃う ときだけ (ガセなし。2026-11-10)
                    Lcd.reach(reach, reach.some(r => r.lines.includes(outcome.winLine)));
                    Sound.chance();
                } else if (outcome.isChance && Math.random() < effects.pushRate) {
                    stopButtons[remaining].classList.add('push');
                    Reels.setLamp(remaining, 'push');
                    Lcd.push();
                }
                // STOP の 色 (2026-10-24): のこりの STOP と ランプが 青 < 赤 < 金 < 虹 で 光る
                const tier = LeverFx.stopTier(heat, config);
                if (tier) {
                    stopButtons[remaining].classList.add(`tier-${tier}`);
                    Reels.setLamp(remaining, `tier-${tier}`);
                    Sound.pushReady(tier === 'rainbow' || tier === 'gold' ? tier : 'red');
                    Collection.seeLever(state, tier === 'rainbow' ? 'stopRainbow' : 'stopTier');
                }
                // 第 3 停止の 長押し (2026-10-24): ためきって 離すと 止まる
                if (LeverFx.longStop(heat, config)) {
                    longStop = { reel: remaining, start: 0, full: false, color: tier ? config.lever.stopTier.colorCodes[tier] : '#ffd700' };
                    stopButtons[remaining].classList.add('long-stop');
                    Lcd.showMessage('長押し!!', longStop.color === 'rainbow' ? '#ffffff' : longStop.color, 8000);
                }
            }
        };
        // 遅れ (2026-10-24): リールが 少し 遅れて 回り出す (チャンス目・BAR 以上)
        if (leverFx.okure) {
            Sound.okure();
            await new Promise(r => setTimeout(r, config.lever.okure.ms));
        }
        // 逆回転 (2026-10-24): リールが しばらく 逆に 回る (7揃い・7・7・BAR・ロングフリーズ)
        if (leverFx.reverse) {
            Sound.gyaku();
            document.body.classList.add('reel-gyaku');
            [0, 1, 2].forEach(i => setTimeout(() => Reels.setLamp(i, 'freeze'), 0));
            setTimeout(() => document.body.classList.remove('reel-gyaku'), config.lever.reverse.ms);
        }
        // プレミア (2026-10-24 ユーザー指定): 確定 (熱さ 6) の ゲームの 一部で、液晶が ひび割れて おにおにが 出てくる
        if (heat >= 6 && Math.random() < config.premiumCrack.rate) {
            Collection.seeLever(state, 'crack');   // 図鑑と 実績
            await Lcd.playCrack();
        }
        spinSound = setInterval(Sound.spin, 200);
        // 押した 位置から 引き込む (取りこぼしなし。Lottery.retarget)
        await Reels.spin(outcome.stops, effects.timing.reelSpinStagger, onStop, (i, press, fixed) => Lottery.retarget(outcome, i, press, fixed, config, { keepLine: Boolean(reach) }),
            leverFx.reverse ? { reverse: true, reverseMs: config.lever.reverse.ms } : { reverse: zc.iwakan === 'reverse' });
        if (freezePlaying) await freezePlaying;
        clearInterval(spinSound);
        stopButtons.forEach(btn => btn.classList.remove('reach', 'push', 'long-stop', 'holding', 'tier-blue', 'tier-red', 'tier-gold', 'tier-rainbow'));
        longStop = null;
        Lcd.setCharge(null);
        Lcd.stopPreview();

        // 揃ったライン・チャンス目の図柄を光らせる
        if (outcome.winLine !== null) Reels.highlight(Lottery.lineCells(outcome.winLine), 'win');
        lightLine(outcome.winLine);
        // リールの 上の ランプ: 揃ったら 金、チャンス目は ピンク、ロングフリーズは 虹
        const lamp = outcome.isFreeze ? 'freeze' : outcome.winLine !== null ? 'win' : outcome.isChance ? 'chance' : '';
        [0, 1, 2].forEach(i => Reels.setLamp(i, lamp));
        if (outcome.chance) Reels.highlight(outcome.chance.cells, 'chance-cell');
        if (outcome.isFreeze) Reels.highlight(outcome.freezeCells, 'freeze-cell');

        // リーチの結果
        if (reach) {
            // リーチしたラインが揃えば GET!! (揃った 絵柄が 光る)、別のラインで揃った・チャンス目のときはそれぞれの表示
            const won = reach.find(r => r.lines.includes(outcome.winLine));
            const result = won ? 'get' : outcome.isChance ? 'chance' : 'no';
            await Lcd.reachResult(result, won ? won.symbol : null);
        }

        if (outcome.aligned) Sound.win();
        // チャンス目ごとの演出
        if (outcome.isChance) await Lcd.playChanceEffect(outcome.chanceName);
        // ゲームの 結果を 先に 決めて (液晶・表示は PUSH の あと)、PUSH を 結果に 合わせて 選び直す (2026-10-27。Hype.reveal)
        //   長押しの チャージ (ためきれたら 得): 通常時・城突入チャレンジは 結果を PUSH の あとに 決める。
        //   PUSH の 色は ためきれなかった ときの 結果で 選ぶ。BATTLE は 結果の あと、ためきれたら 撃破率 UP
        const coinsBefore = state.coins;
        Lcd.hold();   // 液晶の ゲーム数・ランプなどは 演出が 始まるまで 前の まま (結果が 先に 見えないように)
        const replay = GameFlow.replayRng(outcome);   // 先読みと 同じ 乱数
        let events = null, battleCharge = false, ctx;
        if (chargeScene) ctx = GameFlow.chargePreview(state, outcome, config);
        else {
            events = GameFlow.onGameEnd(state, outcome, config, replay);
            battleCharge = GameFlow.battleChargeChance(state, events, config);
            ctx = { ...Hype.contextOf(events, state), charge: battleCharge };
        }
        hype.push = Hype.reveal(hype.push, ctx, config);
        // 図鑑の「レバーの演出」(2026-10-24)
        if (hype.push && hype.push.lever) {
            Collection.seeLever(state, inRash ? 'tatakiRash' : 'tataki');
            if (hype.push.leverChange) Collection.seeLever(state, 'tatakiChange');
        } else if (hype.push && hype.push.mode !== 'tap') Collection.seeLever(state, hype.push.mode === 'long' ? 'pushLong' : 'pushMash');
        // PUSH ボタン: 結果の 前に 押す
        const pushed = hype.push ? await PushButton.wait(hype.push) : null;
        const charged = Boolean(pushed && pushed.charged);
        if (chargeScene) {
            outcome.charged = charged;
            events = GameFlow.onGameEnd(state, outcome, config, replay);
        } else if (battleCharge && charged) events.push(...GameFlow.applyBattleCharge(state, config));
        setPayout(Math.max(0, state.coins - coinsBefore));
        if (config.debug) console.log('outcome', outcome, 'events', events);
        refresh(false);   // 曲は 演出の あとで 次の 場面の 曲に する
        // バトルに負けたときは、演出のあいだ敗北の BGM
        const defeated = events.some(e => (e.type === 'questionResult' && !e.continued) || (e.type === 'naiteiResult' && !e.win));
        if (defeated) Bgm.play('defeat');
        Lcd.release();
        await Lcd.playEvents(events);
        Lcd.setHotFrame(0);
        endIwakan();
        if (Zencho.afterGame(state) || !(state.mode === MODES.NORMAL && state.normal.zone)) setZenchoView(Zencho.active());
        Bgm.setPaused(false);
        refresh();
        UI.showAchievements(events);
        SaveData.save(state);

        setTimeout(() => { spinButton.disabled = false; }, 300);
    }

    // 前兆 (黒い 靄・筐体の 紫の 光) と 違和感演出
    function setZenchoView(kind) {
        Lcd.setZencho(kind);
        document.body.classList.toggle('zencho', Boolean(kind));
        document.body.dataset.zencho = kind || '';
    }
    function playZencho(zc) {
        setZenchoView(zc.zencho);
        // 連続予告「？」(2026-10-24): 前兆の あいだ、ゲームごとに「？」が 増える (色も 白 → 青 → 赤 → 金)
        if (zc.zencho && zc.games) {
            const q = config.lever.question;
            const n = Math.min(q.colors.length, zc.games);
            Lcd.showMessage('？'.repeat(n), q.colors[n - 1], q.ms);
            if (n >= 2) Collection.seeLever(state, 'question');
        }
        if (zc.started) Sound.zencho();
        if (zc.iwakan === 'noise') {
            Lcd.noiseFx(700);
            Sound.noise(0.35, 0.08);
        }
        if (zc.iwakan === 'silent') {
            Sound.setMuted(true);
            Bgm.setPaused(true);
        }
        if (zc.iwakan === 'button') stopButtons.forEach(btn => btn.classList.add('iwakan'));
    }
    function endIwakan() {
        Sound.setMuted(false);
        stopButtons.forEach(btn => btn.classList.remove('iwakan'));
    }

    // レバー ON の レバブル (2026-10-24。js/lever.js): 金棒が ぶるぶる 震える (スマホは 本体も 振動)
    function playLeverFx(fx) {
        if (!fx.buru) return;
        spinButton.classList.remove('lever-buru');
        void spinButton.offsetWidth;
        spinButton.classList.add('lever-buru');
        setTimeout(() => spinButton.classList.remove('lever-buru'), config.lever.buru.ms);
        Sound.leverBuru();
        if (navigator.vibrate) {
            try { navigator.vibrate([60, 30, 60, 30, 60, 30, 120]); } catch (e) { /* 振動できない環境 */ }
        }
    }

    // レバー ON の 演出 (期待度。js/hype.js)
    function playHypeAtLever(hype) {
        document.body.classList.toggle('cab-gold', hype.gold || hype.kakutei);
        // 金・虹の カットインは 当たり 確定 (2026-11-10) なので 確定音 + 重低音 (2026-11-13)
        const sure = hype.kakutei || hype.cutin === 'gold' || hype.cutin === 'rainbow';
        if (sure) {
            Sound.kakutei();
            Sound.juteion();
        } else if (hype.sakibare) Sound.sakibare();
        if (hype.cutin) Lcd.chanceCutIn(hype.cutin, hype.cutinWho);
        Lights.hype(hype);   // 筐体の 光 (カットインの 色・確定は 虹色)
        if (hype.flash !== 'none') {
            const cls = `reel-flash-${hype.flash}`;
            document.body.classList.add(cls);
            setTimeout(() => document.body.classList.remove(cls), hype.flash === 'strong' ? 900 : 500);
            if (hype.flash === 'strong') Lcd.startFlash('#ffffff', 500);
        }
    }

    function buyCoins() {
        state.totalSpent += config.coins.packagePrice;
        state.coins += config.coins.packageAmount;
        buyCoinsButton.classList.remove('attention');
        fsBuyButton.classList.remove('attention');
        Lcd.showMessage('COINS ADDED!');
        refresh();
        SaveData.save(state);
    }

    // ----- 起動 -----
    document.title = config.title;
    document.getElementById('game-title').textContent = config.title;

    const configErrors = Lottery.validate(config);
    if (configErrors.length) {
        configErrors.forEach(err => console.error(err));
        alert('設定ファイルにエラーがあります:\n' + configErrors.join('\n'));
    }

    Lcd.init(document.getElementById('lcd'), config, state);
    // 特化ゾーンの見せ方を選ぶ画面: 選んでいる間はレバーと STOP を押せるようにし、選んだ見せ方を state に入れる
    Lcd.setHandlers({
        chooseTokka: kind => Battle.chooseTokka(state, config, kind),
        selectStart: () => {
            spinButton.disabled = false;
            stopButtons.forEach(btn => { btn.disabled = false; });
        },
        selectEnd: () => {
            spinButton.disabled = true;
            stopButtons.forEach(btn => { btn.disabled = true; });
        }
    });
    Reels.init(config, reelElements, stopButtons);
    UI.init(config, { lever: spinButton, stop1: stopButtons[0], stop2: stopButtons[1], stop3: stopButtons[2] });
    PushButton.init(config);   // PUSH ボタン (2026-10-23 A3)
    Layout.init();   // パソコンでの表示 (一覧 / 全画面)

    spinButton.addEventListener('click', playGame);
    buyCoinsButton.addEventListener('click', buyCoins);
    fsBuyButton.addEventListener('click', buyCoins);   // 全画面のときの BUY
    // STOP は指・マウスが触れた瞬間に止める (離したときの click を待たない)。
    // キーボード・支援技術からの click でも止められるよう両方受け付ける (2回目は無視される)
    // スマホでは回っているリールそのものを押しても止められる (STOP より大きくて押しやすい)。
    // 指で止めたときは短く震わせる (対応している端末だけ)
    // 第 3 停止の 長押し (2026-10-24 ユーザー指定): 押して いる あいだ ため (液晶の ふちが 光る)、ためきって 離すと 止まる。途中で 離すと やり直し
    let longStop = null;   // { reel, start (押しはじめた 時刻。0 は 押して いない), full, color }
    function beginLongStop(i) {
        if (!longStop || longStop.reel !== i || longStop.start) return;
        const start = performance.now();
        longStop.start = start;
        stopButtons[i].classList.add('holding');
        Lcd.showMessage('ためろ!!', longStop.color === 'rainbow' ? '#ffffff' : longStop.color, 8000);
        const tick = () => {
            if (!longStop || longStop.start !== start) return;
            const k = Math.min(1, (performance.now() - start) / config.lever.longStop.ms);
            stopButtons[i].style.setProperty('--progress', String(k));
            Lcd.setCharge(k, longStop.color);
            if (k >= 1 && !longStop.full) {
                longStop.full = true;
                Sound.pushReady('gold');
                Lcd.clearMessage();
                Lcd.setHanase(longStop.color);   // 大きく 点滅 (離すまで。離したあとも 少し 残す)
            }
            requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
    }
    function endLongStop(i) {
        if (!longStop || longStop.reel !== i || !longStop.start) return;
        stopButtons[i].classList.remove('holding');
        stopButtons[i].style.setProperty('--progress', '0');
        if (!longStop.full) {   // ためきる 前に 離した: やり直し
            longStop.start = 0;
            Lcd.setCharge(null);
            Lcd.showMessage('長押し!!', longStop.color === 'rainbow' ? '#ffffff' : longStop.color, 8000);
            return;
        }
        const color = longStop.color === 'rainbow' ? '#ffffff' : longStop.color;
        longStop = null;
        Lcd.setCharge(null);
        Lcd.clearMessage();
        Lcd.setHanase(null);
        Lcd.startFlash(color, 500);
        Collection.seeLever(state, 'longStop');
        Reels.stop(i);
    }
    document.addEventListener('keydown', e => {
        if (!longStop || e.repeat || e.code !== UI.bindingOf(`stop${longStop.reel + 1}`)) return;
        beginLongStop(longStop.reel);
    });
    document.addEventListener('keyup', e => {
        if (longStop && e.code === UI.bindingOf(`stop${longStop.reel + 1}`)) endLongStop(longStop.reel);
    });

    const stopByPointer = (e, i) => {
        if (e.button !== 0) return;
        if (longStop && longStop.reel === i) {   // 長押しの STOP
            e.preventDefault();
            beginLongStop(i);
            return;
        }
        // 特化ゾーンの見せ方を選ぶ画面: 左右の STOP で選び、まんなかの STOP で決定
        if (Lcd.tokkaSelecting()) {
            e.preventDefault();
            Lcd.tokkaSelectInput(`stop${i + 1}`);
            return;
        }
        if (stopButtons[i].disabled) return;
        e.preventDefault();
        Reels.stop(i);
        if (e.pointerType === 'touch' && navigator.vibrate) navigator.vibrate(15);
    };
    stopButtons.forEach((btn, i) => {
        btn.addEventListener('pointerdown', (e) => stopByPointer(e, i));
        btn.addEventListener('click', () => { if (!(longStop && longStop.reel === i)) Reels.stop(i); });   // 長押しの STOP は クリックでは 止めない
    });
    reelElements.forEach((reel, i) => {
        reel.addEventListener('pointerdown', (e) => stopByPointer(e, i));
    });
    [...stopButtons, ...reelElements].forEach((el, k) => ['pointerup', 'pointerleave', 'pointercancel'].forEach(t => el.addEventListener(t, () => endLongStop(k % 3))));
    // 画面の向きが変わると1コマの高さが変わるので、リールの位置を合わせ直す
    window.addEventListener('resize', () => Reels.relayout());

    // デバッグ用の強制遷移
    const debugAction = (fn) => () => {
        if (Reels.isSpinning() || spinButton.disabled) return;
        Lcd.playEvents(fn() || []);
        refresh();
        SaveData.save(state);
    };
    UI.bindDebugActions({
        normal: debugAction(() => DebugState.toNormal(state, config)),
        fillCp: debugAction(() => DebugState.fillChancePoint(state, config)),
        nextMap: debugAction(() => DebugState.nextMap(state, config)),
        challenge: debugAction(() => DebugState.toCastleChallenge(state, config)),
        rash: debugAction(() => DebugState.toRash(state)),
        superRash: debugAction(() => DebugState.toSuperRash(state)),
        lastGame: debugAction(() => DebugState.lastGame(state)),
        setBreak: debugAction(() => DebugState.setBreak(state, config)),
        forceOni: debugAction(() => DebugState.forceEnemy(state, 'onioni')),
        pointChance: debugAction(() => DebugState.forcePointChance(state, config)),
        companion: debugAction(() => DebugState.forceCompanion(state)),
        treasure: debugAction(() => DebugState.forceTreasure(state)),
        naitei: debugAction(() => DebugState.forceNaitei(state)),
        aruaru: debugAction(() => DebugState.forceAruaru(state)),
        finalBlow: debugAction(() => DebugState.forceFinalBlow(state)),
        dance: debugAction(() => DebugState.forceDance(state)),
        revenge: debugAction(() => DebugState.startRevenge(state, config)),
        allCompanions: debugAction(() => DebugState.allCompanions(state, config)),
        revival: debugAction(() => DebugState.toRevival(state, config)),
        opening: () => { if (!Reels.isSpinning() && !spinButton.disabled) Lcd.playOpening(); },
        ending: debugAction(() => [{ type: 'ending' }]),
        endCard: () => {   // RASH 終了画面の絵を、押すたびに次の絵へ
            if (Reels.isSpinning() || spinButton.disabled) return;
            const cards = config.endCard.cards;
            debugEndCard = (debugEndCard + 1) % cards.length;
            Lcd.showMessage(cards[debugEndCard].name, '#fff', 1000);
            Lcd.showEndCard(cards[debugEndCard].id);
        },
        setting: (s) => { DebugState.setSetting(state, s); refresh(); SaveData.save(state); },
        forceGold: debugAction(() => DebugState.forceEnemy(state, config.goldDog.id)),
        coins: debugAction(() => { state.coins += 1000; }),
        nearCeiling: debugAction(() => DebugState.nearCeiling(state, config)),
        heaven: debugAction(() => DebugState.toHeaven(state, config)),
        tokkaFire: debugAction(() => DebugState.forceTokka(state, config, 'fire')),
        tokkaLamp: debugAction(() => DebugState.forceTokka(state, config, 'okaLamp')),
        tokkaIkkeki: debugAction(() => DebugState.forceTokka(state, config, 'ikkeki')),
        tokkaAsahara: debugAction(() => DebugState.forceTokka(state, config, 'asahara')),
        streak10: debugAction(() => DebugState.setStreak(state, config.rash.oni.maxStreak)),
        chanceTime: debugAction(() => DebugState.forceChanceTime(state, config)),
        noticeStepUp: () => { debugNotice = 'stepUp'; },
        noticeGun: () => { debugNotice = 'gun'; }
    });
    document.querySelectorAll('[data-next-role]').forEach(btn => {
        btn.addEventListener('click', () => { debugNextRole = btn.dataset.nextRole; });
    });

    // オープニング: はじめて遊ぶとき (保存データがないとき)・リセットしたあと・台移動したあとに流す。液晶かレバーを押すとスキップ
    document.getElementById('lcd').addEventListener('click', () => Lcd.skipStory());   // オープニング・エンディング
    const openingRequested = SaveData.takeOpeningRequest();
    const opening = !savedState || openingRequested ? Lcd.playOpening() : Promise.resolve();

    refresh();
    if (state.justMoved) {
        // 台移動の直後 (オープニングのあとに表示)
        delete state.justMoved;
        SaveData.save(state);
        opening.then(() => Lcd.showMessage(`${state.machineNo}番台に移動!`, '#7fffd4', 2500));
    } else if (savedState) {
        opening.then(() => Lcd.showMessage('CONTINUE!', '#9fe6ff', 2000));
    }
    // ゲームが更新されていたら、アップデート情報を表示する (はじめて遊ぶとき・表示しない設定のときは出さない。updates.js)
    const updates = UpdateNotes.takePending(!savedState);
    opening.then(() => UI.showUpdates(updates));

    // ホーム画面に追加したときにネットなしでも遊べるようにする (sw.js)。
    // 公開先 (https) だけで動かす: ファイルを直接開いたときは使えず、
    // 手元のサーバー (http://localhost) では版番号を付け直す前の js が古いまま残って紛らわしいため
    if ('serviceWorker' in navigator && location.protocol === 'https:') {
        navigator.serviceWorker.register('sw.js').catch(err => console.warn('サービスワーカーを登録できません:', err));
    }

    // テスト・デバッグ用に公開
    window.__game = { state, config };
})();
